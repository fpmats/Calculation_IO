from ase.io.trajectory import Trajectory
from ase import Atoms
from ase.io.vasp import write_vasp
from ase.io.espresso import read_espresso_in
import os
import re

cwd = os.getcwd()
print(cwd)
directory =cwd+"/POSCARs"

for file in os.listdir(directory): 
    print(file)
    s = file.split("R_")
    #print(s)
    os.system("mkdir Test_Theta_"+s[1])
    os.system("cp POSCARs/"+file+" Test_Theta_"+s[1]+"/POSCAR")
    os.system("cp run_VASP-hprthread.sh Test_Theta_"+s[1]+"/.")
    os.system("cp ASE-VASP-SCF-Torch-VDW.py Test_Theta_"+s[1]+"/.")
