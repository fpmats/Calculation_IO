#!/bin/bash

for i in Test_Theta*; 
do 
   cd $i
   qsub run_VASP-hprthread.sh
   cd ../
done 
