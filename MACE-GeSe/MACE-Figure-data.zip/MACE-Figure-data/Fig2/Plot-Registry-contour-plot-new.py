#Name: Tina Mihm
#Date: May 5, 2025
#Description: Pulls in data from the ASE database and graph it as contour plots and scatter plots

import os
import numpy as np
from ase import Atoms
from ase.io import read, write
import matplotlib.pyplot as plt
import pandas as pd
from ase.geometry import wrap_positions
from ase.io.vasp import write_vasp
#-------------------------------------------------------------------------------------------
from pylab import *
from matplotlib.colors import *
from matplotlib.font_manager import fontManager, FontProperties
from scipy.optimize import curve_fit
from matplotlib.ticker import MaxNLocator

from ase.db import connect

###
### SET UP FIGURE
###
# rcParams['text.usetex'] = True
###
### Fonts
###
rcParams['axes.labelsize'] = 12
rcParams['xtick.labelsize'] = 12
rcParams['ytick.labelsize'] = 12
rcParams['legend.fontsize'] = 10
rcParams['font.family'] = 'serif'
rcParams['font.serif'] = 'Computer Modern Roman'
rcParams['legend.numpoints'] = 1
rcParams['lines.linewidth'] = 2.0
rcParams['lines.markersize'] = 6.0
# http://stackoverflow.com/questions/7906365/matplotlib-savefig-plots-different-from-show
rcParams['savefig.dpi'] = 400
rcParams['figure.dpi'] = 600
###
### Size of the figure
###
# ratio=(np.sqrt(5)-1)/2.0    # golden ratio
# ratio=1                     # square figure
# plt.rcParams["figure.figsize"] = 3.37, 3.37*ratio
# fig = figure()

#---------------------------------------------------------
## System Data
#---------------------------------------------------------
Points = "5000-pnts-"
MACE_model = "MACErcut4.0"

dir_path = "./Database/MACE"
# filename = "/relax-10A.db"
# file_path = dir_path+filename

from matplotlib.colors import LinearSegmentedColormap

cmap = 'Spectral_r'
cmap = 'jet'
# cmap = 'gnuplot2'

# Define the new color you want to add
nc1 = (255/256,255/256,255/256, 1)  # Example: gray color in RGB format
nc2 = (229/256,229/256,255/256, 1)  # Example: gray color in RGB format
nc3 = (178/256,178/256,255/256, 1)  # Example: gray color in RGB format
nc4 = (127/256,127/256,255/256, 1)  # Example: gray color in RGB format
nc5 = (76/256,76/256,255/256, 1)  # Example: gray color in RGB format
nc6 = (25/256,25/256,255/256, 1)  # Example: gray color in RGB format

# Define the existing colormap you want to modify
existing_cmap = plt.cm.jet

# Get the list of colors from the existing colormap
colors = existing_cmap(np.linspace(0, 1, existing_cmap.N))

# Add the new color to the list of colors
# colors = np.vstack((new_color, colors))
colors = np.vstack((nc1, nc2, nc3, nc4, nc5, nc6, colors))

# Create the new colormap
new_cmap = LinearSegmentedColormap.from_list("new_colormap", colors)

# cmap = 'gnuplot2'
# cmap = 'gist_rainbow'
levels = 30

#--------------------------------------------------------------------------------------
## Pull out data from excel and analize
#--------------------------------------------------------------------------------------
cmax = 0
VMIN = 0

## Pull out the Vmin from the 11 A data base to use as reference energy for all plots ##
for filename in os.listdir(dir_path):
    if filename.startswith("relax-11A"):
        file_path = os.path.join(dir_path, filename)
        print(file_path)
        #------
        db = connect(file_path)
        #-----
        # selections = ['model=vasp']
        selections = ['model=macecalculator']
        natoms = db[1].natoms
        A_lat = db[1].a
        B_lat = db[1].b
        layers = natoms/4
        print("number of atoms:", natoms)
        for selection in selections:
            energy = np.array([row.energy for row in db.select(selection)])
            print(energy)
            vmin = np.min([row.energy for row in db.select(selection)])
            VMIN = vmin
            print("VMIN", VMIN)


# ---------------------------------------------------------------------
# # Plot 2D slices
# ---------------------------------------------------------------------

print("Figure 1")

for filename in os.listdir(dir_path):
    if filename.startswith("relax"):
        print(filename)
        Fname = re.findall(r"\d+\.?\d*", filename)
        print(Fname)
        System = Fname[0]+"A-"
        L_dis = float(Fname[0])
        print(L_dis)
        
        file_path = os.path.join(dir_path, filename)
        print(file_path)
        #------
        db = connect(file_path)
        #-----
        # selections = ['model=vasp']
        selections = ['model=macecalculator']
        
        plt.figure(1)
        fig, ax = plt.subplots()

        for selection in selections:
            m = selection.split("=")
            model = m[1]+"-"
            print(model)
            dB_array = np.array([row.dB for row in db.select(selection)])
            dA_array = np.array([row.dA for row in db.select(selection)])
            energy = np.array([row.energy for row in db.select(selection)])
            print(energy)
            vmin = np.min([row.energy for row in db.select(selection)])
            print(L_dis, vmin)
            Ediff = (energy - VMIN)
            # Ediff = (energy - vmin)

            # print(Ediff)
            # print(min(Ediff*1000/layers), max(Ediff*1000/layers))

            # print("vmin of "+str(selection), vmin)

            contour = ax.tricontourf(dA_array, dB_array, Ediff*1000/layers, levels=levels, cmap=cmap)

            cbar = plt.colorbar(contour)  # Add colorbar
            cbar.set_label(r'$\Delta E$ (meV/layer)')

            #------------------------
            ax.set_xlabel(r'$\Delta a$')
            ax.set_ylabel(r'$\Delta b$')
            # plt.savefig("GeSe-Grid-Search-"+model+System+Points+MACE_model+".png", bbox_inches='tight', transparent=False)
            plt.savefig("MACE/GeSe-Grid-Search-"+model+System+Points+MACE_model+"-Rel-11A-min-energy.png", bbox_inches='tight', transparent=False)
            plt.close()
            plt.clf()

#---------------------------------------------------------------------
## Plot energy vs dB for one dA for all layers
#---------------------------------------------------------------------

print("Figure 2")

plt.figure(2)
fig, ax = plt.subplots()

DeltaC = []
E_dC = []

t = 0

for filename in os.listdir(dir_path):
    if filename.startswith("relax"):
        print(filename)
        Fname = re.findall(r"\d+\.?\d*", filename)
        # print(Fname)
        System = Fname[0]+"A-"
        L_dis = float(Fname[0])
        print(L_dis)
        
        file_path = os.path.join(dir_path, filename)
        print(file_path)
        #------
        db = connect(file_path)
        #-----
        # selections = ['model=vasp']
        selections = ['model=macecalculator']

        for selection in selections:
            m = selection.split("=")
            model = m[1]+"-"
            # print(model)
            dB_array = np.array([row.dB for row in db.select(selection)])
            dA_array = np.array([row.dA for row in db.select(selection)])
            dB_sort = np.sort(np.unique(dB_array))
            dA_sort = np.sort(np.unique(dA_array))

            m = selection.split("=")
            model = m[1]+"-"
            # print(model)
            print(dA_sort[-7]) ## dA = 3.5226132040826084
            dA_val = dA_sort[-7]
            db_val_list = [dB_sort[1], dB_sort[18], dB_sort[35], dB_sort[51], dB_sort[68]]
            dB_array = np.array([row.dB for row in db.select(f'dA={dA_val},'+selection)])
            E_array = np.array([row.energy for row in db.select(f'dA={dA_val},'+selection)])

            E_val_list = []
            for i in db_val_list: 
                print(i)
                E_val_list += [db.get(f'dA={dA_val}, dB={i},'+selection).energy]
                if round(i, 8) == 2.29608881: 
                    print(i)
                    DeltaC +=[L_dis]
                    E_dC += [db.get(f'dA={dA_val}, dB={i},'+selection).energy]

            Ediff = (E_array - VMIN)

            Ediff_val = (E_val_list - VMIN)

            ax.plot(dB_array, Ediff*1000/layers, color='black', marker = "o", linestyle='')
            ax.plot(db_val_list, Ediff_val*1000/layers, color="#00ff96", marker = "o", linestyle='')
        # t = t+1
            # #------------------------
            # ax.set_xlim(-0.1, max(dB_array)+0.1 )
            # ax.set_xticks(np.arange(0, B_lat, 0.5))
            # ax.set_xlabel(r'$\Delta b$')
            # ax.set_ylabel(r'$\Delta E$ (meV/layer)')
            # plt.savefig("GeSe-Grid-Search-energy-vs-dB_at_dA-"+str(dA_val)+"_C-"+str(L_dis)+System+Points+MACE_model+".png", bbox_inches='tight')
#------------------------
ax.set_xlim(-0.1, max(dB_array)+0.1 )
ax.set_xticks(np.arange(0, B_lat, 0.5))
ax.set_xlabel(r'$\Delta b$')
ax.set_ylabel(r'$\Delta E$ (meV/layer)')
fig.savefig("MACE/GeSe-Grid-Search-energy-vs-dB_at_dA-"+MACE_model+"-all-Rel-11A-min-energy.png", bbox_inches='tight')
plt.close()
plt.clf() 
    
print("print dB and dA values")
print(dB_sort)
print(dA_sort)


#---------------------------------------------------------------------
## Plot 3D graph from 2D slices
#---------------------------------------------------------------------
Off = []
Dist = []
levels = 100

print("Figure 3")

fig2 = plt.figure(3)
ax2 = fig2.add_subplot(projection = '3d')
# plt.rcParams["figure.figsize"] = 3.37, (3.37)*ratio*2
# mpl.rcParams["font.weight"] = "bold"
# mpl.rcParams["axes.labelweight"] = "bold"

cmin = 0
cmax = 400 
# cmax = cmax+100
# cmax = cmax - 200

# order = [11, 12, 10]
# order = [10, 11, 12]
# order = [10, 10.5, 11.5, 12, 12.5, 11]
order = [10.5, 11.5, 11]
# ticks = [(i - 11) for i in order]
ticks = [10.6, 11.6, 11.1]
ticks = [-0.25, 0.25, 0.0]

# for filename in sorted(os.listdir(dir_path), reverse=True):
for d in order: 
    offset = d
    if offset == 10.5: 
        offset = d
    if offset == 11: 
        offset = d+10
    if offset == 11.5: 
        offset = d+20
    Off +=[offset]
    for filename in os.listdir(dir_path):
        if filename.startswith("relax-"+str(d)):
            print(filename)
            Fname = re.findall(r"\d+\.?\d*", filename)
            print(Fname)
            System = Fname[0]+"A-"
            L_dis = float(Fname[0])
            Dist +=[L_dis]
            file_path = os.path.join(dir_path, filename)
            print(file_path)
            #------
            db = connect(file_path)
            #-----
            # selections = ['model=vasp', 'model=macecalculator']
            selections = ['model=macecalculator']
                    
            for selection in selections:
                m = selection.split("=")
                model = m[1]+"-"
                print(model)
                dB_array = np.array([row.dB for row in db.select(selection)])
                dA_array = np.array([row.dA for row in db.select(selection)])
                energy = np.array([row.energy for row in db.select(selection)])
                print(energy)
                Ediff = (energy - VMIN)

                print(VMIN)
                print("Vmin", VMIN)

                print(Ediff)
                print("Ediff min and max (meV/layer):", min(Ediff)*1000/layers, max(Ediff)*1000/layers)
                print(cmin, cmax)
                print(cmax)
                print(levels)
                contour2 = ax2.tricontourf(dA_array, dB_array, Ediff*1000/layers, zdir='z', offset=offset,levels=levels, cmap=cmap, vmax = cmax)

                # if L_dis == 10 or L_dis == 12: 
                #     contour2 = ax2.tricontourf(dA_array, dB_array, Ediff*1000/layers, zdir='z', offset=offset,levels=levels, cmap=cmap, vmax = cmax)
                # else: 
                    # contour2 = ax2.tricontourf(dA_array, dB_array, Ediff*1000/layers, zdir='z', offset=offset,levels=levels, cmap=cmap, vmax = cmax)

print("This is Cmin/max", cmin, cmax)

# cbar2 = fig.colorbar(contour2, ax = ax2, shrink=0.5, aspect=10, extend='max')  # Add colorbar
# # cbar2.set_label(r'$\Delta E$ (meV/atom)')
cbar2 = plt.cm.ScalarMappable(cmap=cmap)
# cbar2 = plt.cm.ScalarMappable(cmap=new_cmap)
cbar2.set_array([0, cmax])
plt.colorbar(cbar2, shrink=0.5, aspect=10, extend='max', label='$\Delta E$ (meV/layer)', pad=0.0)
# plt.colorbar(cbar2, shrink=0.5, aspect=10, label='$\Delta E$ (meV/layer)', pad=0.01)

            
            #------------------------
ax2.set_xlabel(r'$\Delta a$ ($\AA$)', labelpad=0.5)
ax2.set_ylabel(r'$\Delta b$ ($\AA$)', labelpad=0.5)
ax2.zaxis.set_rotate_label(False)
# ax2.set_zlabel(r'$\Delta c \AA$', rotation = 90, labelpad=0.5)
ax2.set_zlabel(r'$\Delta d_i$ ($\AA$)', rotation = 90, labelpad=1.0)
ax2.set_xticks(np.arange(0, A_lat, 1))
ax2.set_yticks(np.arange(0, B_lat, 1))
ax2.set_zlim(9, 13)
ax2.set_zticks(Off, labels=[l for l in ticks], rotation = 30)

# Change axes tick mark labels
ax2.tick_params(axis='x', pad=-1)
ax2.tick_params(axis='y', pad=-1)
ax2.tick_params(axis='z', pad=1)

# Change axes colors
ax2.xaxis.line.set_color('gray')
ax2.yaxis.line.set_color('gray')
ax2.zaxis.line.set_color('white')

# Set background color
ax2.set_facecolor((0,0,0,0))
ax2.xaxis.set_pane_color((1.0, 1.0, 1.0, 0.0))
ax2.yaxis.set_pane_color((1.0, 1.0, 1.0, 0.0))
ax2.zaxis.set_pane_color((1.0, 1.0, 1.0, 0.0))
# make the grid lines transparent
ax2.xaxis._axinfo["grid"]['color'] =  (1,1,1,0)
ax2.yaxis._axinfo["grid"]['color'] =  (1,1,1,0)
ax2.zaxis._axinfo["grid"]['color'] =  (1,1,1,0)


# sets angle view along Z (elev), and angle along x/y (azim)
ax2.view_init(elev=15, azim=60)

fig2.tight_layout(pad=-0.5)
# fig2.savefig("GeSe-Grid-Search-"+System+Points+MACE_model+"-3D.png", bbox_inches='tight', transparent=True)
fig2.savefig("MACE/GeSe-Grid-Search-"+Points+MACE_model+"-3D-Rel-11A-min-energy-2.png", transparent=True)

##------------------------------------------
