from ase.db import connect
import ase.db
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import matplotlib.cm as cm
from itertools import product
from matplotlib.ticker import MultipleLocator
from scipy.interpolate import griddata
import matplotlib.tri as tri
from ase.io.vasp import write_vasp

# db = connect('./relax.db')
# db = connect('./relax-vasp2.db')
# db = connect('./relax-vasp3.db')
# db = connect('./relax-vasp3-MP.db')
db = connect('./relax-vasp-T2.db')
db2 = connect('./relax-mace-vaspOPT-2.db')

# db = connect('./relax_updated_withMACEMP.db')
natoms = db[1].natoms
print("number of atoms:", natoms)
nlayer = natoms/4
print(nlayer)
Graph = "MACE-MP"
# Graph = "No-MACE-MP"

if Graph == "No-MACE-MP":
    fig, axs = plt.subplots(1,2,figsize=[5,2.5], sharex=True,sharey=True, width_ratios=[0.42,0.55])
    plt.subplots_adjust(wspace=None, hspace=None)
    selections1 = ['model=vasp']
    selections2 = ['model=macecalculator']

if Graph == "MACE-MP":
    fig, axs = plt.subplots(1,3,figsize=[8,2.5], sharex=True,sharey=True, width_ratios=[0.2,0.2,0.25])
    # selections = ['model=macecalculator','model=vasp', 'model=mace-mpcalculator']
    selections1 = ['model=macecalculator','model=vasp']
    selections2 = ['model=macecalculator']

# selections = ['model=macecalculator']
# selections = ['model=mace-mpcalculator']
# selections = ['model=vasp']

vmin = np.min([row.energy for row in db.select()])
print("total vmin:", vmin)
# vmax = vmin+0.24
vmax = vmin+0.48
# vmax = np.max([row.energy for row in db.select()])
levels = (np.linspace(vmin, vmax, 11)-vmin)*1000/natoms
levels2 = (np.linspace(vmin, vmax, 11)-vmin)*1000/nlayer
print(levels)

cmap=plt.cm.Blues_r
# cmap='Spectral_r'
cmap='rainbow'
cmap='RdYlBu'

for selection,ax in zip(selections1,axs):
    ax.set_box_aspect(1)
    b_array = np.array([row.b for row in db.select(selection)])
    a_array = np.array([row.a for row in db.select(selection)])
    energy = np.array([row.energy for row in db.select(selection)])
    eng = [row.energy for row in db.select(selection)]
    print("selection 1", selection)
    b_sort = np.sort(np.unique(b_array))
    a_sort = np.sort(np.unique(a_array))
    print(b_sort)
    print(a_sort)
    print(len(b_sort), len(a_sort))

    energy_all = np.concatenate((energy, np.flip(energy)))

    B,A = np.meshgrid(b_sort, a_sort)
    E = np.zeros_like(B)
    vmin = np.min([row.energy for row in db.select(selection)])
    if selection == 'model=macecalculator':
        a_min = 3.8581001759
        b_min = 4.5265750885
        mace_min_E = -35.54834183
        mace_diff = (mace_min_E-vmin)*1000/nlayer
        print("MACE B structure, MP:", mace_min_E)
        print("MACE min E structure:", vmin)
        print("MACE diff:", mace_diff)
    if selection == 'model=vasp':
        a_min = 3.8581001759
        b_min = 4.5265750885
        vasp_min_E = -35.630346
        vasp_diff = (vasp_min_E-vmin)*1000/nlayer
        print("VASP diff:", vasp_diff)

    print(vmin)
    # vmax2 = np.max([row.energy for row in db.select(selection)])
    print("vmin of "+str(selection), vmin)
    print("vmax of "+str(selection), vmax)
    # vmax = vmin+0.24
    vmax = vmin+0.48
    vmax2 = vmin+0.6
    # vmax2 = vmin+0.8
    levels = (np.linspace(vmin, vmax, 11)-vmin)*1000/natoms
    levels2 = (np.linspace(vmin, vmax2, 21)-vmin)*1000/nlayer
    
    if selection == 'model=vasp':
        print(selection)
        energy = np.array([row.energy for row in db.select(selection)])
        Emin = min(energy)
        Min_ID = np.where(energy == Emin)
        print("this is the min energy :", Emin)
        print("this is the min energy index:", Min_ID)
        print("length:", len(b_array), len(a_array), len(energy))
        print("length sort:", len(b_sort), len(a_sort))
        print(b_sort)
        print(a_sort)
        id_array = np.array([row.id for row in db.select(selection)])
        print("this is the min energy ID:", id_array[Min_ID[0]][0])

        B_array = []
        A_array = []
        Eng = []
        index = []
        for i in range(0,len(b_array)): 
            if b_array[i] == a_array[i]: 
                print("This is diagonal:", b_array[i], a_array[i])
                index += [i]
        print("index",index)
        # index = index[:-4]
        # print(index)
        for i in range(0,len(b_array)): 
            if b_array[i] != a_array[i]:
                B_array.append(b_array[i])
                A_array.append(a_array[i])
                Eng.append(energy[i])
            if b_array[i] == a_array[i]: 
                for test in index: 
                    if i == test: 
                        B_array.append(b_array[i])
                        A_array.append(a_array[i])
                        Eng.append(energy[i])
        print("length new:", len(B_array), len(A_array), len(Eng))
        for i in range(0,len(B_array)): 
            if B_array[i] == A_array[i]: 
                print("This is diagonal:", B_array[i], A_array[i])
        B_array = np.array(B_array[:])
        B_array = np.around(B_array, decimals=2)
        A_array = np.array(A_array[:])
        A_array = np.around(A_array, decimals=2)
        Eng = np.array(Eng[:])
        print("length rounded:", len(B_array), len(A_array), len(Eng))
        B_sort = np.sort(np.unique(B_array))
        A_sort = np.sort(np.unique(A_array))
        print("length sort:", len(B_sort), len(A_sort))

        if selection == 'model=vasp':
            # for i in b_sort: 
            #     print("test", i)
            #     A_t = db.get(f'b={i},'+selection).a
            #     print(A_t)
            n = 0
            for i in b_sort: 
                print(i)
            print("this is a for VASP:")
            for row in db.select(selection): 
                # b_t = row.b
                # if b_t == 4.8: 
                #     print(row.b, row.a, row.energy, row.id)
                #     n = n+1
                b_t = row.b
                a_t = row.a
                ID_ind = row.id
                if ID_ind == id_array[Min_ID[0]][0]: 
                    print(row.b, row.a, row.energy, row.id)
                if b_t == 4.1 and a_t == 4.1: 
                    at = row.toatoms()
                    write_vasp("POSCAR_VASP_4.1_4.1.vasp", at)
                    n = n+1
            print(n)
 
            B,A = np.meshgrid(b_sort, a_sort)
            E = np.zeros_like(B)
            for (i,j) in np.array(np.where(B)).T:
                E[i,j] = db.get(f'b={B[i,j]},a={A[i,j]},'+selection).energy
            # per layer
            cs = axs[1].contourf(B,A,1000*(E-vmin)/nlayer, #interpolation='bilinear', cmap=cm.RdYlGn,
                     levels2,
                     extend='max',
                     cmap=cmap,
                     #origin="lower"
                     #vmax=vmax, vmin=vmin
                    )
    if selection == 'model=macecalculator':
        print(selection)
        energy = np.array([row.energy for row in db.select(selection)])
        Emin = min(energy)
        Min_ID = np.where(energy == Emin)
        print("this is the min energy :", Emin)
        print("this is the min energy index:", Min_ID)
        # print("energy", energy)
        print("length:", len(b_array), len(a_array), len(energy))
        print("length sort:", len(b_sort), len(a_sort))
        print(b_sort)
        print(a_sort)
        id_array = np.array([row.id for row in db.select(selection)])
        print("this is the min energy ID:", id_array[Min_ID[0]][0])

        print("this is a for MACE:")
        for row in db.select(selection): 
            # b_t = row.b
            # if b_t == 4.8: 
            #     print(row.b, row.a, row.energy, row.id)
            #     n = n+1
            b_t = row.b
            a_t = row.a
            c_t = row.c
            ID_ind = row.id
            if ID_ind == id_array[Min_ID[0]][0]: 
                print(row.b, row.a, row.energy, row.id)
            if b_t == 4.0 and a_t == 4.0: 
                at = row.toatoms()
                write_vasp("POSCAR_MACE_4.0_4.0.vasp", at)

        B_array = []
        A_array = []
        Eng = []
        index = []
        for i in range(0,len(b_array)): 
            if b_array[i] == a_array[i]: 
                print("This is diagonal:", b_array[i], a_array[i])
                index += [i]
        print("index",index)
        # index = index[:-4]
        # print(index)
        for i in range(0,len(b_array)): 
            if b_array[i] != a_array[i]:
                B_array.append(b_array[i])
                A_array.append(a_array[i])
                Eng.append(energy[i])
            if b_array[i] == a_array[i]: 
                for test in index: 
                    if i == test: 
                        B_array.append(b_array[i])
                        A_array.append(a_array[i])
                        Eng.append(energy[i])
        print("length new:", len(B_array), len(A_array), len(Eng))
        for i in range(0,len(B_array)): 
            if B_array[i] == A_array[i]: 
                print("This is diagonal:", B_array[i], A_array[i])
        B_array = np.array(B_array[:])
        B_array = np.around(B_array, decimals=2)
        A_array = np.array(A_array[:])
        A_array = np.around(A_array, decimals=2)
        Eng = np.array(Eng[:])
        print("length rounded:", len(B_array), len(A_array), len(Eng))
        B_sort = np.sort(np.unique(B_array))
        A_sort = np.sort(np.unique(A_array))
        print("length sort:", len(B_sort), len(A_sort))

        if selection == 'model=macecalculator': 
            B,A = np.meshgrid(b_sort, a_sort)
            E = np.zeros_like(B)
            for (i,j) in np.array(np.where(B)).T:
                E[i,j] = db.get(f'b={B[i,j]},a={A[i,j]},'+selection).energy
            print("energy")
            print(1000*(E-vmin)/nlayer)

            # per layer
            cs = axs[0].contourf(B,A,1000*(E-vmin)/nlayer, #interpolation='bilinear', cmap=cm.RdYlGn,
                     levels2,
                     extend='max',
                     cmap=cmap,
                     #origin="lower"
                     #vmax=vmax, vmin=vmin
                    )

for selection,ax in zip(selections2,axs):
    ax.set_box_aspect(1)
    b_array = np.array([row.b for row in db2.select(selection)])
    a_array = np.array([row.a for row in db2.select(selection)])
    energy = np.array([row.energy for row in db2.select(selection)])
    eng = [row.energy for row in db2.select(selection)]
    print("selection", selection)
    b_sort = np.sort(np.unique(b_array))
    a_sort = np.sort(np.unique(a_array))
    print(b_sort)
    print(a_sort)
    print(len(b_sort), len(a_sort))

    energy_all = np.concatenate((energy, np.flip(energy)))

    B,A = np.meshgrid(b_sort, a_sort)
    E = np.zeros_like(B)
    vmin = np.min([row.energy for row in db2.select(selection)])
    if selection == 'model=macecalculator':
        a_min = 3.8581001759
        b_min = 4.5265750885
        mace_min_E = -35.54834183
        mace_diff = (mace_min_E-vmin)*1000/nlayer
        print("MACE B structure, MP:", mace_min_E)
        print("MACE min E structure:", vmin)
        print("MACE diff:", mace_diff)

    print(vmin)
    # vmax2 = np.max([row.energy for row in db2.select(selection)])
    print("vmin of "+str(selection), vmin)
    print("vmax of "+str(selection), vmax)
    # vmax = vmin+0.24
    vmax = vmin+0.48
    vmax2 = vmin+0.6
    # vmax2 = vmin+0.8
    levels = (np.linspace(vmin, vmax, 11)-vmin)*1000/natoms
    levels2 = (np.linspace(vmin, vmax2, 21)-vmin)*1000/nlayer
    
    if selection == 'model=macecalculator':
        print(selection)
        energy = np.array([row.energy for row in db2.select(selection)])
        # print("energy", energy)
        print("length:", len(b_array), len(a_array), len(energy))
        print("length sort:", len(b_sort), len(a_sort))
        print(b_sort)
        print(a_sort)
        id = np.array([row.id for row in db2.select(selection)])

        B_array = []
        A_array = []
        Eng = []
        index = []
        for i in range(0,len(b_array)): 
            if b_array[i] == a_array[i]: 
                print("This is diagonal:", b_array[i], a_array[i])
                index += [i]
        print("index",index)
        # index = index[:-4]
        # print(index)
        for i in range(0,len(b_array)): 
            if b_array[i] != a_array[i]:
                B_array.append(b_array[i])
                A_array.append(a_array[i])
                Eng.append(energy[i])
            if b_array[i] == a_array[i]: 
                for test in index: 
                    if i == test: 
                        B_array.append(b_array[i])
                        A_array.append(a_array[i])
                        Eng.append(energy[i])
        print("length new:", len(B_array), len(A_array), len(Eng))
        for i in range(0,len(B_array)): 
            if B_array[i] == A_array[i]: 
                print("This is diagonal:", B_array[i], A_array[i])
        B_array = np.array(B_array[:])
        B_array = np.around(B_array, decimals=2)
        A_array = np.array(A_array[:])
        A_array = np.around(A_array, decimals=2)
        Eng = np.array(Eng[:])
        print("length rounded:", len(B_array), len(A_array), len(Eng))
        B_sort = np.sort(np.unique(B_array))
        A_sort = np.sort(np.unique(A_array))
        print("length sort:", len(B_sort), len(A_sort))

        if selection == 'model=macecalculator': 
            # B,A = np.meshgrid(b_sort, a_sort)
            # E = np.zeros_like(B)
            # for (i,j) in np.array(np.where(B)).T:
            #     print(B[i,j])
            #     print(A[i,j])
            #     E[i,j] = db2.get(f'b={B[i,j]},a={A[i,j]},'+selection).energy
            # print("energy")
            # print(1000*(E-vmin)/nlayer)

            # # per layer
            # cs = axs[2].contourf(B,A,1000*(E-vmin)/nlayer, #interpolation='bilinear', cmap=cm.RdYlGn,
            #          levels2,
            #          extend='max',
            #          cmap=cmap,
            #          #origin="lower"
            #          #vmax=vmax, vmin=vmin
            #         )
            cs = axs[2].tricontourf(A_array,B_array,1000*(Eng-vmin)/nlayer, #interpolation='bilinear', cmap=cm.RdYlGn,
                        levels2,
                        extend='max',
                        cmap=cmap,
                        #origin="lower"
                        #vmax=vmax, vmin=vmin
                        )

    
# fig.savefig('GeSe_PES-3.png',dpi=300)
# fig.savefig('GeSe_PES-5-layers.png',dpi=300)
if Graph == "No-MACE-MP":
    axs[0].xaxis.set_major_locator(MultipleLocator(0.2))
    axs[0].yaxis.set_major_locator(MultipleLocator(0.2))
    padding = 0.05
    axs[0].set_xlim([a_array.min()-padding,a_array.max()+padding])
    axs[0].set_ylim([b_array.min()-padding,b_array.max()+padding])
    axs[0].set_xlabel(r'b ($\AA{}$)') 
    axs[0].set_ylabel(r'a ($\AA{}$)') 
    axs[1].set_xlabel(r'b ($\AA{}$)')

    axs[1].text(3.8,4.9,'MACE[PBE]+D3') 
    axs[0].text(4.0,4.9,'PBE+D3') 

    #axs[1].tick_params(labelleft=False) 

    # fig.colorbar(cs,label="rel. E (meV/atom)")
    # fig.colorbar(cs,label="Energy (meV/atom)")
    cbar = fig.colorbar(cs,label="Energy (meV/layer)", pad=0.09, shrink=0.8)
    # cbar.ax.axhline(y=mace_diff, color='#00FF96', linestyle='-')
    # cbar.ax.axhline(y=vasp_diff, color='#9600ff', linestyle='-')
    axs[0].tick_params(axis='both', which='major', labelsize=8) 
    axs[1].tick_params(axis='both', which='major', labelsize=8) 

    fig.tight_layout()
    # fig.savefig('GeSe_PES-layers.png',dpi=300)
    # fig.savefig('GeSe_PES-layers-test-new-MACE-test-minE-structure.png',dpi=300)
    # fig.savefig('GeSe_PES-layers-test-new-MACE-3.png',dpi=300)
    fig.savefig('GeSe_PES-layers-test-vaspOPT.png',dpi=300) ## overleaf fig title

if Graph == "MACE-MP":
    axs[0].xaxis.set_major_locator(MultipleLocator(0.2))
    axs[0].yaxis.set_major_locator(MultipleLocator(0.2))
    padding = 0.05
    axs[0].set_xlim([a_array.min()-padding,a_array.max()+padding])
    axs[0].set_ylim([b_array.min()-padding,b_array.max()+padding])
    axs[0].set_xlabel(r'b ($\AA{}$)') 
    axs[0].set_ylabel(r'a ($\AA{}$)') 
    axs[1].set_xlabel(r'b ($\AA{}$)')
    axs[2].set_xlabel(r'b ($\AA{}$)')
    axs[0].text(3.8,4.87,'MACE+D3, MACE OPT') 
    axs[1].text(4.1,4.87,'PBE+D3') 
    axs[2].text(3.95,4.87,'MACE-MP+D3, VASP OPT') 

    #axs[1].tick_params(labelleft=False) 

    # fig.colorbar(cs,label="rel. E (meV/atom)")
    # fig.colorbar(cs,label="Energy (meV/atom)")
    fig.colorbar(cs,label="Energy (meV/layer)")
    

    fig.tight_layout()
    # fig.savefig('GeSe_PES-layers-wMACE-MP.png',dpi=300)
    fig.savefig('GeSe_PES-layers-test-new-MACE-MP-new.png',dpi=300)